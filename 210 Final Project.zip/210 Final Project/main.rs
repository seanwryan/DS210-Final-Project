extern crate csv;
extern crate statrs;

use std::error::Error;
use std::fs::File;
use std::io::BufReader;

fn main() -> Result<(), Box<dyn Error>> {
    let file = File::open("songs.csv")?;
    let reader = csv::Reader::from_reader(BufReader::new(file));

    let mut x_values = Vec::new();
    let mut y_values = Vec::new();
    for result in reader.records() {
        let record = result?;
        let x: f64 = record[0].parse()?;
        let y: f64 = record[1].parse()?;
        x_values.push(x);
        y_values.push(y);
    }

    let (slope, intercept, r) = statrs::linear_regression(&x_values, &y_values);

    let r_squared = r * r;

    println!("Line of best fit: y = {}x + {}", slope, intercept);
    println!("R squared: {}", r_squared);

    Ok(())
}
