use std::fs::File;
use std::io::{BufReader, Result};
use csv::Reader;

fn main() -> Result<()> {
    let file = File::open("vgsales.csv").unwrap();
    let reader = BufReader::new(file);
    let mut csv_reader = Reader::from_reader(reader);

    for result in csv_reader.records() {
        let record = result?;
        // Process the record here
    }

    Ok(())
}
